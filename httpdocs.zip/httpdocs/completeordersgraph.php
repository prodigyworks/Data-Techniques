<?php
	include("system-header.php"); 
?>
	<img src='graphs/graph1.php' />
<?php
	include("system-footer.php"); 
?>