<?php
	include("system-header.php"); 
?>
	<img src="images/admin.png" />
<?php
	include("system-footer.php"); 
?>