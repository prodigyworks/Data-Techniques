<?php include("system-header.php"); ?>

<!--  Start of content -->
<div>
	<p align="center">&nbsp;</p>
	<h4 align="center" class="err">Login Failed!<br />Please check your username and password</h4>
	<?php showErrors(); ?>
</div>

<!--  End of content -->

<?php include("system-footer.php"); ?>