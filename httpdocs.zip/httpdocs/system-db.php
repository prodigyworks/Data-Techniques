<?php
require_once("quotationitem.php");
	
function start_db() {
	date_default_timezone_set('Europe/London'); 
	
	if(!isset($_SESSION)) {
		session_start();
	}
	
	error_reporting(E_ALL ^ E_DEPRECATED);

	/*
	define('DB_HOST', 'localhost');
    define('DB_USER', 'root');
    define('DB_PASSWORD', 'root');
    define('DB_DATABASE', 'datatechnique');
    */
	define('DB_HOST', '83.222.229.27');
    define('DB_USER', 'dtcrmuser');
    define('DB_PASSWORD', 'KwdC5yWtFn');
    define('DB_DATABASE', 'dtcrmdb');
	/*
    
	define('DB_HOST', 'prodigyworks.co.uk.mysql');
    define('DB_USER', 'prodigyworks_co');
    define('DB_PASSWORD', 'i6qFAWND');
    define('DB_DATABASE', 'prodigyworks_co');
    */
/*
 * Database:

Server IP: 213.171.193.147

DB Name: dtcrmdb

User: dtcrmuser

Pass: KwdC5yWtFn


 */
}

function GetCostCode($costcode) {
	if ($costcode == "CAPEXCCF") {
		return "CAPEX DEAL RELATED CCF";
			
	} else if ($costcode == "CAPEXINTERNAL") {
		return "CAPEX NON DEAL RELATED";	
		
	} else if ($costcode == "OPEXINTERNAL") {
		return "OPEX NON DEAL RELATED";	
			
	} else if ($costcode == "CAPEXBESPOKE") {
		return "CAPEX - BESPOKE";	
			
	} else if ($costcode == "OPEXBESPOKE") {
		return "OPEX - BESPOKE";	
			
	} else if ($costcode == "OPEXCUSTOMERPO") {
		return "OPEX - Customer PO";	
	}
}

function GetUserName($userid = "") {
	if ($userid == "") {
		return $_SESSION['SESS_FIRST_NAME'] . " " . $_SESSION['SESS_LAST_NAME'];
		
	} else {
		$qry = "SELECT * FROM datatech_members A " .
				"WHERE A.member_id = $userid ";
		$result = mysql_query($qry);
		$name = "Unknown";
	
		//Check whether the query was successful or not
		if($result) {
			while (($member = mysql_fetch_assoc($result))) {
				$name = $member['firstname'] . " " . $member['lastname'];
			}
		}
		
		return $name;
	}
}

function GetEmail($userid) {
	$qry = "SELECT email FROM datatech_members A " .
			"WHERE A.member_id = $userid ";
	$result = mysql_query($qry);
	$name = "Unknown";

	//Check whether the query was successful or not
	if($result) {
		while (($member = mysql_fetch_assoc($result))) {
			$name = $member['email'];
		}
	}
	
	return $name;
}

function GetSiteName($siteid) {
	$qry = "SELECT * FROM datatech_sites A " .
			"WHERE A.id = $siteid ";
	$result = mysql_query($qry);
	$name = "Unknown";

	//Check whether the query was successful or not
	if($result) {
		while (($member = mysql_fetch_assoc($result))) {
			$name = $member['name'];
		}
	}
	
	return $name;
}

function GetSiteAddress($siteid) {
	$qry = "SELECT * FROM datatech_sites A " .
			"WHERE A.id = $siteid ";
	$result = mysql_query($qry);
	$name = "Unknown";

	//Check whether the query was successful or not
	if($result) {
		while (($member = mysql_fetch_assoc($result))) {
			$name = $member['name'];
			
			if ($member['address1'] != "") $name = $name . "\n" . $member['address1'];
			if ($member['address2'] != "") $name = $name . "\n" . $member['address2'];
			if ($member['address3'] != "") $name = $name . "\n" . $member['address3'];
			if ($member['address4'] != "") $name = $name . "\n" . $member['address4'];
			if ($member['address5'] != "") $name = $name . "\n" . $member['address5'];
			if ($member['address6'] != "") $name = $name . "\n" . $member['address6'];
			if ($member['address7'] != "") $name = $name . "\n" . $member['address7'];
		}
	}
	
	return $name;
}

function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "")  
{ 
  $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue; 
 
  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue); 
 
  switch ($theType) { 
    case "text": 
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL"; 
      break;     
    case "long": 
    case "int": 
      $theValue = ($theValue != "") ? intval($theValue) : "NULL"; 
      break; 
    case "double": 
      $theValue = ($theValue != "") ? "'" . doubleval($theValue) . "'" : "NULL"; 
      break; 
    case "date": 
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL"; 
      break; 
    case "defined": 
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue; 
      break; 
  } 
  return $theValue; 
} 

function initialise_db() {
		//Connect to mysql server
		$link = mysql_connect(DB_HOST, DB_USER, DB_PASSWORD);
		
		if (!$link) {
			die('Failed to connect to server: ' . mysql_error());
		}
		
		//Select database
		$db = mysql_select_db(DB_DATABASE);
		
		if(!$db) {
			die("Unable to select database");
		}
	
}
	
function dateStampString($oldnotes, $newnotes, $prefix = "") {
	if ($newnotes == $oldnotes) {
		return $oldnotes;
	}
	
	return 
		mysql_escape_string (
				$oldnotes . "\n\n" .
				$prefix . " - " . 
				date("F j, Y, H:i a") . " : " . 
				$_SESSION['SESS_FIRST_NAME'] . " " . 
				$_SESSION['SESS_LAST_NAME'] . "\n" . 
				$newnotes
			);
}
	
function smtpmailer($to, $from, $from_name, $subject, $body) { 
	global $error;
	
	$headers  = 'MIME-Version: 1.0' . "\r\n";
	$headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";
	
	// Additional headers
	$headers .= "To: <$to>" . "\r\n";
	$headers .= "From: $from_name <$from>" . "\r\n";
	
	mail(
			$to,
			$subject,
			$body,
			$headers
		);
}
function smtpmailer2($to, $from, $from_name, $subject, $body) { 
	global $error;
	$mail = new PHPMailer();  // create a new object
	$mail->IsSMTP(); // enable SMTP
	$mail->SMTPDebug = 0;  // debugging: 1 = errors and messages, 2 = messages only
	$mail->SMTPAuth = true;  // authentication enabled
//	$mail->SMTPAuth = false;  // authentication enabled
	$mail->SMTPSecure = 'ssl'; // secure transfer enabled REQUIRED for GMail
	$mail->Host = 'smtp.gmail.com';
//	$mail->Host = 'send.one.com';
	$mail->Port = 465; 
//	$mail->Port = 25; 
	$mail->Username = "istudentcontrol@gmail.com";  
	$mail->Password = "istudent";           
//	$mail->Username = "kevin.hilton@prodigyworks.co.uk";  
//	$mail->Password = "Jasmin717440";           
	$mail->SetFrom($from, $from_name);
	$mail->IsHTML(true);
	$mail->Subject = $subject;
	$mail->Body = $body;
	$mail->AddAddress($to);
	if(!$mail->Send()) {
		$error = 'Mail error: '.$mail->ErrorInfo; 
		return false;
	} else {
		$error = 'Message sent!';
		return true;
	}
}

function sendRoleMessage($role, $subject, $message) {
	require_once('phpmailer/class.phpmailer.php');

	$qry = "SELECT B.email FROM datatech_userroles A " .
			"INNER JOIN datatech_members B " .
			"ON B.member_id = A.memberid " .
			"WHERE A.roleid = '$role' ";
	$result = mysql_query($qry);

	//Check whether the query was successful or not
	if($result) {
		while (($member = mysql_fetch_assoc($result))) {
			smtpmailer($member['email'], 'admin@dti.com', 'DTi Administration', $subject, $message);
		}
	}
	
	if (!empty($error)) echo $error;
}
	
function endsWith( $str, $sub ) {
	return ( substr( $str, strlen( $str ) - strlen( $sub ) ) == $sub );
}

function isAuthenticated() {
	return ! (!isset($_SESSION['SESS_MEMBER_ID']) || (trim($_SESSION['SESS_MEMBER_ID']) == ''));
}

function sendUserMessage($id, $subject, $message) {
	require_once('phpmailer/class.phpmailer.php');

	$qry = "SELECT B.email FROM datatech_members B " .
			"WHERE B.member_id = $id ";
	$result = mysql_query($qry);

	//Check whether the query was successful or not
	if($result) {
		while (($member = mysql_fetch_assoc($result))) {
			smtpmailer($member['email'], 'admin@dti.com', 'DTi Administration', $subject, $message);
		}
	}
	
	if (!empty($error)) echo $error;
}

function createCombo($id, $value, $name, $table, $where = " ") {
	echo "<select id='" . $id . "'  name='" . $id . "'>";
	createComboOptions($value, $name, $table, $where);
	
	echo "</select>";
}
	

function createComboOptions($value, $name, $table, $where = " ", $blank = true) {
	if ($blank) {
		echo "<option value='0'></option>";
	}
		
	$qry = "SELECT * " .
			"FROM $table " .
			$where . " " . 
			"ORDER BY $name";
	$result = mysql_query($qry);
	
	if ($result) {
		while (($member = mysql_fetch_assoc($result))) {
			echo "<option value=" . $member[$value] . ">" . $member[$name] . "</option>";
		}
	}
}
	
function escape_notes($notes) {
	return str_replace("\r", "", str_replace("'", "\\'", str_replace("\n", "\\n", str_replace("\"", "\\\"", str_replace("\\", "\\\\", $notes)))));
}
    
function isUserInRole($roleid) {
	if (! isAuthenticated()) {
		return false;
	}
	
	for ($i = 0; $i < count($_SESSION['ROLES']); $i++) {
		if ($roleid == $_SESSION['ROLES'][$i]) {
			return true;
		}
	}
	
	return false;
}

function lastIndexOf($string, $item) {
	$index = strpos(strrev($string), strrev($item));

	if ($index) {
		$index = strlen($string) - strlen($item) - $index;
		
		return $index;
		
	} else {
		return -1;
	}
}


?>