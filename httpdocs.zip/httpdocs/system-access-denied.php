<?php include("system-header.php"); ?>

<!--  Start of content -->
<p align="center">&nbsp;</p>
<h4 align="center" class="err">Access Denied!<br />You do not have access to this resource.</h4>
<!--  End of content -->

<?php include("system-footer.php"); ?>