<?php include("system-header.php"); ?>

<!--  Start of content -->
<div style="height:500px">
	<p align="center">&nbsp;</p>
	<h4 align="center" class="err">Login Timeout!<br />Your session was idle for 5 minutes</h4>
	<?php showErrors(); ?>
</div>

<!--  End of content -->
<?php
	include("system-footer.php"); 
?>