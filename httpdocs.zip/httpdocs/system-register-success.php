<?php include("system-header.php"); ?>

<!--  Start of content -->

<div style="height:500px">
	<h4>User information successfully saved.</h4>
</div>
<!--  End of content -->

<?php include("system-footer.php"); ?>