<?php 
	include("system-header.php"); 
?>
<center style="padding-top:30px">
<img src="images/reports.png" />
</center>
<?php include("system-footer.php"); ?>